#include "MainComponent.h"

MainComponent::MainComponent()
{
    // Build the data model. nullptr means "no undo" for this initial set-up.
    pet.setProperty (IDs::name, "Fluffmuff", nullptr);
    pet.setProperty (IDs::animal, "Cat", nullptr);

    juce::ValueTree accessories (IDs::Accessories);
    pet.addChild (accessories, -1, nullptr);

    juce::ValueTree collar (IDs::Collar);
    collar.setProperty (IDs::colour, "Pink", nullptr);
    accessories.addChild (collar, -1, nullptr);

    // Listen only after set-up, so the log starts empty.
    pet.addListener (this);
    undoManager.addChangeListener (this);

    // Option 2: a listener class (this component) for the clock button.
    addAndMakeVisible (checkTime);
    checkTime.addListener (this);

    addAndMakeVisible (timeLabel);
    timeLabel.setJustificationType (juce::Justification::centred);

    // Option 1: lambda callbacks for everything else.
    for (auto* b : { &rename, &addCamera, &undo, &redo, &save, &load })
        addAndMakeVisible (*b);

    rename.onClick = [this]
    {
        undoManager.beginNewTransaction ("Rename pet");   // one step per click
        pet.setProperty (IDs::name,
                         pet[IDs::name].toString() == "Fluffmuff" ? "Whiskers" : "Fluffmuff",
                         &undoManager);
    };

    addCamera.onClick = [this]
    {
        undoManager.beginNewTransaction ("Add camera");

        juce::ValueTree camera (IDs::Camera);
        camera.setProperty (IDs::hasFlash, false, nullptr);   // not yet in the tree, so no undo
        camera.setProperty (IDs::capacity, 32, nullptr);
        pet.getChildWithName (IDs::Accessories).addChild (camera, -1, &undoManager);
    };

    undo.onClick = [this] { undoManager.undo(); };
    redo.onClick = [this] { undoManager.redo(); };

    save.onClick = [this]
    {
        if (auto xml = pet.createXml())
        {
            if (xml->writeTo (getSaveFile()))
                log ("Saved to " + getSaveFile().getFullPathName());
            else
                log ("Could not save to " + getSaveFile().getFullPathName());
        }
    };

    load.onClick = [this]
    {
        if (auto parsed = juce::XmlDocument::parse (getSaveFile()))
        {
            auto loaded = juce::ValueTree::fromXml (*parsed);

            if (loaded.hasType (IDs::Pet))
            {
                // Copy into the existing node so our listener stays attached.
                undoManager.beginNewTransaction ("Load pet");
                pet.copyPropertiesAndChildrenFrom (loaded, &undoManager);
            }
        }
        else
        {
            log ("Nothing saved yet: press Save first");
        }
    };

    logView.setMultiLine (true);
    logView.setReadOnly (true);
    addAndMakeVisible (logView);

    changeListenerCallback (&undoManager);   // set the initial button states
    log (pet.toXmlString());

    setSize (460, 420);
}

MainComponent::~MainComponent()
{
    checkTime.removeListener (this);
    pet.removeListener (this);
    undoManager.removeChangeListener (this);
}

void MainComponent::resized()
{
    auto area = getLocalBounds().reduced (10);

    auto placeRow = [&area] (std::initializer_list<juce::Component*> items)
    {
        auto row = area.removeFromTop (32);
        const auto width = row.getWidth() / (int) items.size();

        for (auto* item : items)
            item->setBounds (row.removeFromLeft (width).reduced (2, 0));

        area.removeFromTop (6);
    };

    checkTime.setBounds (area.removeFromTop (40));
    timeLabel.setBounds (area.removeFromTop (30));
    area.removeFromTop (6);

    placeRow ({ &rename, &addCamera });
    placeRow ({ &undo, &redo, &save, &load });

    logView.setBounds (area);
}

void MainComponent::buttonClicked (juce::Button* button)
{
    if (button == &checkTime)          // one listener often serves several broadcasters
        timeLabel.setText (juce::Time::getCurrentTime().toString (true, true),
                           juce::dontSendNotification);
}

void MainComponent::valueTreePropertyChanged (juce::ValueTree& tree, const juce::Identifier& property)
{
    log (tree.getType().toString() + "." + property.toString()
         + " is now " + tree[property].toString());
}

void MainComponent::valueTreeChildAdded (juce::ValueTree& parent, juce::ValueTree& child)
{
    log (child.getType().toString() + " added to " + parent.getType().toString());
}

void MainComponent::valueTreeChildRemoved (juce::ValueTree& parent, juce::ValueTree& child, int)
{
    log (child.getType().toString() + " removed from " + parent.getType().toString());
}

void MainComponent::changeListenerCallback (juce::ChangeBroadcaster*)
{
    undo.setEnabled (undoManager.canUndo());
    redo.setEnabled (undoManager.canRedo());
}

void MainComponent::log (const juce::String& message)
{
    DBG (message);
    logView.moveCaretToEnd();
    logView.insertTextAtCaret (message + "\n");
}

juce::File MainComponent::getSaveFile() const
{
    return juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("ListenersDemoPet.xml");
}
