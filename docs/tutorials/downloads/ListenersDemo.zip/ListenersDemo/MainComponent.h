#pragma once

#include <juce_gui_extra/juce_gui_extra.h>

namespace IDs
{
    #define DECLARE_ID(name) const juce::Identifier name (#name);
    DECLARE_ID (Pet)        DECLARE_ID (name)     DECLARE_ID (animal)
    DECLARE_ID (Accessories) DECLARE_ID (Collar)  DECLARE_ID (Camera)
    DECLARE_ID (colour)     DECLARE_ID (hasFlash) DECLARE_ID (capacity)
    #undef DECLARE_ID
}

class MainComponent final : public juce::Component,
                            private juce::Button::Listener,
                            private juce::ValueTree::Listener,
                            private juce::ChangeListener
{
public:
    MainComponent();
    ~MainComponent() override;

    void resized() override;

private:
    // juce::Button::Listener
    void buttonClicked (juce::Button* button) override;

    // juce::ValueTree::Listener (every callback has an empty default)
    void valueTreePropertyChanged (juce::ValueTree& tree, const juce::Identifier& property) override;
    void valueTreeChildAdded (juce::ValueTree& parent, juce::ValueTree& child) override;
    void valueTreeChildRemoved (juce::ValueTree& parent, juce::ValueTree& child, int index) override;

    // juce::ChangeListener: the UndoManager is a ChangeBroadcaster
    void changeListenerCallback (juce::ChangeBroadcaster* source) override;

    void log (const juce::String& message);
    juce::File getSaveFile() const;

    juce::UndoManager undoManager;      // declared first, so it outlives the tree
    juce::ValueTree pet { IDs::Pet };

    juce::TextButton checkTime { "Check the time..." };
    juce::Label timeLabel;
    juce::TextButton rename { "Rename" }, addCamera { "Add camera" };
    juce::TextButton undo { "Undo" }, redo { "Redo" }, save { "Save" }, load { "Load" };
    juce::TextEditor logView;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MainComponent)
};
