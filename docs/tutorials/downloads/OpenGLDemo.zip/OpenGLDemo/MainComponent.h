#pragma once

#include <juce_opengl/juce_opengl.h>

class MainComponent final : public juce::OpenGLAppComponent
{
public:
    MainComponent()  { setSize (800, 600); }
    ~MainComponent() override { shutdownOpenGL(); }

    void initialise() override
    {
        using namespace ::juce::gl;

        auto newShader = std::make_unique<juce::OpenGLShaderProgram> (openGLContext);

        if (newShader->addVertexShader (juce::OpenGLHelpers::translateVertexShaderToV3 (vertexShader))
            && newShader->addFragmentShader (juce::OpenGLHelpers::translateFragmentShaderToV3 (fragmentShader))
            && newShader->link())
        {
            shader = std::move (newShader);
            shader->use();

            position       = std::make_unique<juce::OpenGLShaderProgram::Attribute> (*shader, "position");
            sourceColour   = std::make_unique<juce::OpenGLShaderProgram::Attribute> (*shader, "sourceColour");
            projectionMatrix = std::make_unique<juce::OpenGLShaderProgram::Uniform>  (*shader, "projectionMatrix");
            viewMatrix       = std::make_unique<juce::OpenGLShaderProgram::Uniform>  (*shader, "viewMatrix");

            const Vertex vertices[] = { { {  0.0f,  0.8f, 0.0f }, { 1.0f, 0.0f, 0.0f, 1.0f } },
                                        { { -0.8f, -0.6f, 0.0f }, { 0.0f, 1.0f, 0.0f, 1.0f } },
                                        { {  0.8f, -0.6f, 0.0f }, { 0.0f, 0.0f, 1.0f, 1.0f } } };

            glGenBuffers (1, &vertexBuffer);
            glBindBuffer (GL_ARRAY_BUFFER, vertexBuffer);
            glBufferData (GL_ARRAY_BUFFER, (GLsizeiptr) sizeof (vertices), vertices, GL_STATIC_DRAW);
        }
        else
        {
            DBG (newShader->getLastError());       // shader compile or link errors land here
        }
    }

    void shutdown() override
    {
        using namespace ::juce::gl;

        if (vertexBuffer != 0)
            glDeleteBuffers (1, &vertexBuffer);

        vertexBuffer = 0;
        position.reset(); sourceColour.reset(); projectionMatrix.reset(); viewMatrix.reset();
        shader.reset();
    }

    void render() override
    {
        using namespace ::juce::gl;

        jassert (juce::OpenGLHelpers::isContextActive());
        if (shader == nullptr) return;

        auto scale = (float) openGLContext.getRenderingScale();         // retina and HiDPI
        juce::OpenGLHelpers::clear (getLookAndFeel().findColour (juce::ResizableWindow::backgroundColourId));

        glEnable (GL_BLEND);
        glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        const auto area = getRenderBounds();                            // snapshot taken under the lock
        glViewport (0, 0, juce::roundToInt (scale * (float) area.getWidth()),
                          juce::roundToInt (scale * (float) area.getHeight()));

        shader->use();
        projectionMatrix->setMatrix4 (getProjectionMatrix (area).mat, 1, false);
        viewMatrix->setMatrix4       (getViewMatrix().mat,       1, false);

        glBindBuffer (GL_ARRAY_BUFFER, vertexBuffer);
        glVertexAttribPointer (position->attributeID,     3, GL_FLOAT, GL_FALSE, sizeof (Vertex), nullptr);
        glVertexAttribPointer (sourceColour->attributeID, 4, GL_FLOAT, GL_FALSE, sizeof (Vertex),
                               (GLvoid*) (sizeof (float) * 3));
        glEnableVertexAttribArray (position->attributeID);
        glEnableVertexAttribArray (sourceColour->attributeID);

        glDrawArrays (GL_TRIANGLES, 0, 3);

        glDisableVertexAttribArray (position->attributeID);
        glDisableVertexAttribArray (sourceColour->attributeID);
        glBindBuffer (GL_ARRAY_BUFFER, 0);
    }

    void paint (juce::Graphics&) override {}        // GL draws the content
    void resized() override
    {
        const juce::ScopedLock lock (mutex);   // resized() runs on the message thread, render() on the GL thread
        bounds = getLocalBounds();
    }

private:
    struct Vertex { float position[3]; float colour[4]; };

    juce::Rectangle<int> getRenderBounds() const
    {
        const juce::ScopedLock lock (mutex);
        return bounds;
    }

    static juce::Matrix3D<float> getProjectionMatrix (juce::Rectangle<int> area)
    {
        auto w = 1.0f / (0.5f + 0.1f);                                        // half-width at the near plane
        auto h = w * area.toFloat().getAspectRatio (false);                   // keep the aspect ratio
        return juce::Matrix3D<float>::fromFrustum (-w, w, -h, h, 4.0f, 30.0f);
    }

    juce::Matrix3D<float> getViewMatrix() const
    {
        auto view     = juce::Matrix3D<float>::fromTranslation ({ 0.0f, 0.0f, -10.0f });
        auto rotation = view.rotation ({ 0.0f, 5.0f * std::sin ((float) getFrameCounter() * 0.01f), 0.0f });
        return view * rotation;
    }

    const juce::String vertexShader = R"(
        attribute vec4 position;
        attribute vec4 sourceColour;
        uniform mat4 projectionMatrix;
        uniform mat4 viewMatrix;
        varying vec4 destinationColour;
        void main()
        {
            destinationColour = sourceColour;
            gl_Position = projectionMatrix * viewMatrix * position;
        })";

    const juce::String fragmentShader =
       #if JUCE_OPENGL_ES
        R"(varying lowp vec4 destinationColour;)"
       #else
        R"(varying vec4 destinationColour;)"
       #endif
        R"(
        void main()
        {
            gl_FragColor = destinationColour;
        })";

    std::unique_ptr<juce::OpenGLShaderProgram> shader;
    std::unique_ptr<juce::OpenGLShaderProgram::Attribute> position, sourceColour;
    std::unique_ptr<juce::OpenGLShaderProgram::Uniform> projectionMatrix, viewMatrix;
    juce::uint32 vertexBuffer = 0;

    mutable juce::CriticalSection mutex;   // guards `bounds`
    juce::Rectangle<int> bounds;           // the component's size, as last seen by resized()
};
