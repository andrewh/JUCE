#pragma once

#include <juce_audio_utils/juce_audio_utils.h>
#include <juce_dsp/juce_dsp.h>

//==============================================================================
// Small utility processors share a base class that fills in the boilerplate
class ProcessorBase : public juce::AudioProcessor
{
public:
    using AudioProcessor::processBlock;   // keep the double-precision overload visible
    ProcessorBase()
        : AudioProcessor (BusesProperties()
                            .withInput  ("Input",  juce::AudioChannelSet::stereo())
                            .withOutput ("Output", juce::AudioChannelSet::stereo())) {}

    void prepareToPlay (double, int) override {}
    void releaseResources() override {}
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override {}

    juce::AudioProcessorEditor* createEditor() override { return nullptr; }
    bool hasEditor() const override                     { return false; }

    const juce::String getName() const override         { return {}; }
    bool acceptsMidi() const override                   { return false; }
    bool producesMidi() const override                  { return false; }
    double getTailLengthSeconds() const override        { return 0; }

    int getNumPrograms() override                       { return 0; }
    int getCurrentProgram() override                    { return 0; }
    void setCurrentProgram (int) override               {}
    const juce::String getProgramName (int) override    { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock&) override {}
    void setStateInformation (const void*, int) override {}
};

class GainProcessor final : public ProcessorBase
{
public:
    using AudioProcessor::processBlock;   // keep the double-precision overload visible
    GainProcessor() { gain.setGainDecibels (-6.0f); }

    void prepareToPlay (double sampleRate, int samplesPerBlock) override
    {
        gain.prepare ({ sampleRate, (juce::uint32) samplesPerBlock, 2 });
    }

    void processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&) override
    {
        juce::dsp::AudioBlock<float> block (buffer);
        gain.process (juce::dsp::ProcessContextReplacing<float> (block));
    }

    void reset() override { gain.reset(); }
    const juce::String getName() const override { return "Gain"; }

private:
    juce::dsp::Gain<float> gain;
};

class OscillatorProcessor final : public ProcessorBase
{
public:
    using AudioProcessor::processBlock;   // keep the double-precision overload visible
    OscillatorProcessor()
    {
        osc.setFrequency (440.0f);
        osc.initialise ([] (float x) { return std::sin (x); });
    }

    void prepareToPlay (double sampleRate, int samplesPerBlock) override
    {
        osc.prepare ({ sampleRate, (juce::uint32) samplesPerBlock, 2 });
    }

    void processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&) override
    {
        juce::dsp::AudioBlock<float> block (buffer);
        osc.process (juce::dsp::ProcessContextReplacing<float> (block));
    }

    void reset() override { osc.reset(); }
    const juce::String getName() const override { return "Oscillator"; }

private:
    juce::dsp::Oscillator<float> osc;
};

class FilterProcessor final : public ProcessorBase
{
public:
    using AudioProcessor::processBlock;   // keep the double-precision overload visible
    void prepareToPlay (double sampleRate, int samplesPerBlock) override
    {
        *filter.state = *juce::dsp::IIR::Coefficients<float>::makeHighPass (sampleRate, 1000.0f);
        filter.prepare ({ sampleRate, (juce::uint32) samplesPerBlock, 2 });
    }

    void processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&) override
    {
        juce::dsp::AudioBlock<float> block (buffer);
        filter.process (juce::dsp::ProcessContextReplacing<float> (block));
    }

    void reset() override { filter.reset(); }
    const juce::String getName() const override { return "Filter"; }

private:
    juce::dsp::ProcessorDuplicator<juce::dsp::IIR::Filter<float>,
                                   juce::dsp::IIR::Coefficients<float>> filter;
};

//==============================================================================
// The hosting plug-in: owns the graph and rebuilds it when the slots change
class ChannelStrip final : public juce::AudioProcessor,
                           private juce::Timer
{
public:
    using IOProcessor = juce::AudioProcessorGraph::AudioGraphIOProcessor;
    using Node        = juce::AudioProcessorGraph::Node;

    ChannelStrip();
    ~ChannelStrip() override;

    bool isBusesLayoutSupported (const BusesLayout&) const override;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    using AudioProcessor::processBlock;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override                     { return true; }

    const juce::String getName() const override         { return "Channel Strip"; }
    bool acceptsMidi() const override                   { return true; }
    bool producesMidi() const override                  { return true; }
    double getTailLengthSeconds() const override        { return 0.0; }

    int getNumPrograms() override                       { return 1; }
    int getCurrentProgram() override                    { return 0; }
    void setCurrentProgram (int) override               {}
    const juce::String getProgramName (int) override    { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;

private:
    void buildGraph();
    void connectStereo (Node& source, Node& destination);
    std::unique_ptr<juce::AudioProcessor> createProcessor (int choiceIndex);
    bool parametersChanged() const;
    void timerCallback() override;   // message thread

    static inline const juce::StringArray choices { "Empty", "Oscillator", "Gain", "Filter" };

    juce::CriticalSection graphLock;   // serialises graph changes: the timer versus prepareToPlay() and releaseResources()
    std::unique_ptr<juce::AudioProcessorGraph> graph;
    juce::AudioParameterChoice* slotParams[3];
    juce::AudioParameterBool*   bypassParams[3];
    Node::Ptr slotNodes[3];                             // touched on the message thread only
    std::atomic<int>  builtChoices[3] { -1, -1, -1 };   // atomic: prepareToPlay() may run off the message thread
    std::atomic<bool> builtBypass[3]  { false, false, false };
    Node::Ptr audioIn, audioOut, midiIn, midiOut;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ChannelStrip)
};
