#include "PluginProcessor.h"

ChannelStrip::ChannelStrip()
    : AudioProcessor (BusesProperties()
                        .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                        .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      graph (new juce::AudioProcessorGraph()),
      slotParams { new juce::AudioParameterChoice ({ "slot1", 1 }, "Slot 1", choices, 0),
                   new juce::AudioParameterChoice ({ "slot2", 1 }, "Slot 2", choices, 0),
                   new juce::AudioParameterChoice ({ "slot3", 1 }, "Slot 3", choices, 0) },
      bypassParams { new juce::AudioParameterBool ({ "bypass1", 1 }, "Bypass 1", false),
                     new juce::AudioParameterBool ({ "bypass2", 1 }, "Bypass 2", false),
                     new juce::AudioParameterBool ({ "bypass3", 1 }, "Bypass 3", false) }
{
    for (auto* p : slotParams)   addParameter (p);
    for (auto* p : bypassParams) addParameter (p);

    startTimerHz (20);   // polls for slot changes on the message thread
}

ChannelStrip::~ChannelStrip() { stopTimer(); }

bool ChannelStrip::isBusesLayoutSupported (const BusesLayout& l) const
{
    auto in = l.getMainInputChannelSet(), out = l.getMainOutputChannelSet();
    return ! in.isDisabled() && in == out
           && (out == juce::AudioChannelSet::mono() || out == juce::AudioChannelSet::stereo());
}

void ChannelStrip::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    const juce::ScopedLock lock (graphLock);   // the timer can rebuild the graph at the same time

    graph->setPlayConfigDetails (getMainBusNumInputChannels(),
                                 getMainBusNumOutputChannels(),
                                 sampleRate, samplesPerBlock);
    buildGraph();   // topology first, so prepareToPlay() below renders these nodes straight away
    graph->prepareToPlay (sampleRate, samplesPerBlock);
}

void ChannelStrip::releaseResources()
{
    const juce::ScopedLock lock (graphLock);
    graph->releaseResources();
}

void ChannelStrip::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    for (int i = getTotalNumInputChannels(); i < getTotalNumOutputChannels(); ++i)
        buffer.clear (i, 0, buffer.getNumSamples());

    graph->processBlock (buffer, midi);
}

void ChannelStrip::buildGraph()
{
    using Update = juce::AudioProcessorGraph::UpdateKind;

    graph->clear (Update::none);   // batch every change below, then publish once with rebuild()

    audioIn  = graph->addNode (std::make_unique<IOProcessor> (IOProcessor::audioInputNode), std::nullopt, Update::none);
    audioOut = graph->addNode (std::make_unique<IOProcessor> (IOProcessor::audioOutputNode), std::nullopt, Update::none);
    midiIn   = graph->addNode (std::make_unique<IOProcessor> (IOProcessor::midiInputNode), std::nullopt, Update::none);
    midiOut  = graph->addNode (std::make_unique<IOProcessor> (IOProcessor::midiOutputNode), std::nullopt, Update::none);

    // MIDI passes straight through
    graph->addConnection ({ { midiIn->nodeID,  juce::AudioProcessorGraph::midiChannelIndex },
                            { midiOut->nodeID, juce::AudioProcessorGraph::midiChannelIndex } },
                           Update::none);

    // Create a node for each chosen slot; empty slots have no node
    for (int i = 0; i < 3; ++i)
    {
        builtChoices[i] = slotParams[i]->getIndex();
        slotNodes[i]    = builtChoices[i] == 0 ? nullptr
                                               : graph->addNode (createProcessor (builtChoices[i]), std::nullopt, Update::none);

        builtBypass[i] = *bypassParams[i];
        if (slotNodes[i] != nullptr)
            slotNodes[i]->setBypassed (builtBypass[i]);   // skips the processor, passes audio through
    }

    // Wire audio input -> each present slot in order -> audio output
    auto* previous = audioIn.get();
    for (auto& slot : slotNodes)
    {
        if (slot == nullptr) continue;
        connectStereo (*previous, *slot);
        previous = slot.get();
    }
    connectStereo (*previous, *audioOut);

    graph->rebuild();   // publish the finished graph in one go
}

void ChannelStrip::connectStereo (Node& source, Node& destination)
{
    for (int channel = 0; channel < 2; ++channel)
        graph->addConnection ({ { source.nodeID, channel }, { destination.nodeID, channel } },
                              juce::AudioProcessorGraph::UpdateKind::none);
}

std::unique_ptr<juce::AudioProcessor> ChannelStrip::createProcessor (int choiceIndex)
{
    switch (choiceIndex)
    {
        case 1: return std::make_unique<OscillatorProcessor>();
        case 2: return std::make_unique<GainProcessor>();
        case 3: return std::make_unique<FilterProcessor>();
        default: return nullptr;
    }
}

bool ChannelStrip::parametersChanged() const           // message thread: compares the parameters with what was built
{
    for (int i = 0; i < 3; ++i)
        if (slotParams[i]->getIndex() != builtChoices[i]
            || (bool) *bypassParams[i] != builtBypass[i])
            return true;

    return false;
}

void ChannelStrip::timerCallback()   // message thread
{
    const juce::ScopedLock lock (graphLock);

    if (parametersChanged())         // a slot or bypass changed: rebuild
        buildGraph();
}

// A generic editor lists the slot and bypass parameters automatically
juce::AudioProcessorEditor* ChannelStrip::createEditor()
{
    return new juce::GenericAudioProcessorEditor (*this);
}

void ChannelStrip::getStateInformation (juce::MemoryBlock& dest)
{
    juce::XmlElement xml ("ChannelStrip");
    for (int i = 0; i < 3; ++i)
    {
        xml.setAttribute ("slot" + juce::String (i + 1), slotParams[i]->getIndex());
        xml.setAttribute ("bypass" + juce::String (i + 1), (bool) *bypassParams[i]);
    }
    copyXmlToBinary (xml, dest);
}

void ChannelStrip::setStateInformation (const void* data, int size)
{
    if (auto xml = getXmlFromBinary (data, size))
        if (xml->hasTagName ("ChannelStrip"))
            for (int i = 0; i < 3; ++i)
            {
                *slotParams[i]   = xml->getIntAttribute ("slot" + juce::String (i + 1), 0);
                *bypassParams[i] = xml->getBoolAttribute ("bypass" + juce::String (i + 1), false);
            }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new ChannelStrip();
}
