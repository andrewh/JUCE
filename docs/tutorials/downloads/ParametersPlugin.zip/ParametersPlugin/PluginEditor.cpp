#include "PluginEditor.h"

MyEditor::MyEditor (MyProcessor& p)
    : AudioProcessorEditor (&p)
{
    gainLabel.setText ("Gain", juce::dontSendNotification);
    gainLabel.attachToComponent (&gainSlider, true);
    invertButton.setButtonText ("Invert Phase");

    modeBox.addItemList (juce::StringArray { "Clean", "Warm", "Hot" }, 1);   // items first, IDs from 1

    for (auto* c : std::initializer_list<juce::Component*> { &gainSlider, &invertButton, &modeBox, &gainLabel })
        addAndMakeVisible (c);

    gainAttachment   = std::make_unique<SliderAttachment>   (p.apvts, "gain",   gainSlider);
    invertAttachment = std::make_unique<ButtonAttachment>   (p.apvts, "invert", invertButton);
    modeAttachment   = std::make_unique<ComboBoxAttachment> (p.apvts, "mode",   modeBox);

    setSize (400, 140);
}

void MyEditor::resized()
{
    auto area = getLocalBounds().reduced (10);
    gainSlider.setBounds   (area.removeFromTop (40).withTrimmedLeft (60));
    invertButton.setBounds (area.removeFromTop (30));
    modeBox.setBounds      (area.removeFromTop (30));
}
