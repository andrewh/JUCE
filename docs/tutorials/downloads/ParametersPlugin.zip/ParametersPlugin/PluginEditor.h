#pragma once

#include "PluginProcessor.h"

class MyEditor final : public juce::AudioProcessorEditor
{
public:
    explicit MyEditor (MyProcessor&);

    void resized() override;

private:
    juce::Slider gainSlider;
    juce::Label gainLabel;
    juce::ToggleButton invertButton;
    juce::ComboBox modeBox;

    using SliderAttachment   = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment   = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using ComboBoxAttachment = juce::AudioProcessorValueTreeState::ComboBoxAttachment;

    // Declared after the controls, so they are destroyed (and detach) first
    std::unique_ptr<SliderAttachment>   gainAttachment;
    std::unique_ptr<ButtonAttachment>   invertAttachment;
    std::unique_ptr<ComboBoxAttachment> modeAttachment;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MyEditor)
};
