#include "PluginProcessor.h"
#include "PluginEditor.h"

MyProcessor::MyProcessor()
    : AudioProcessor (BusesProperties()
                        .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                        .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "Parameters", createLayout())      // nullptr: no undo manager
{
    gainParam   = apvts.getRawParameterValue ("gain");
    invertParam = apvts.getRawParameterValue ("invert");
}

juce::AudioProcessorValueTreeState::ParameterLayout MyProcessor::createLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;

    layout.add (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { "gain", 1 }, "Gain",
        juce::NormalisableRange<float> (0.0f, 1.0f), 0.5f));

    layout.add (std::make_unique<juce::AudioParameterBool> (
        juce::ParameterID { "invert", 1 }, "Invert Phase", false));

    layout.add (std::make_unique<juce::AudioParameterChoice> (
        juce::ParameterID { "mode", 1 }, "Mode",
        juce::StringArray { "Clean", "Warm", "Hot" }, 0));

    return layout;
}

void MyProcessor::prepareToPlay (double, int)
{
    previousGain = gainParam->load() * (invertParam->load() < 0.5f ? 1.0f : -1.0f);   // no ramp from zero
}

bool MyProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    return layouts.getMainOutputChannelSet() == juce::AudioChannelSet::stereo()
        && layouts.getMainInputChannelSet() == layouts.getMainOutputChannelSet();
}

void MyProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    auto target = gainParam->load() * (invertParam->load() < 0.5f ? 1.0f : -1.0f);

    if (juce::approximatelyEqual (target, previousGain))
        buffer.applyGain (target);
    else
    {
        buffer.applyGainRamp (0, buffer.getNumSamples(), previousGain, target);   // no clicks
        previousGain = target;
    }
}

void MyProcessor::getStateInformation (juce::MemoryBlock& dest)
{
    auto state = apvts.copyState();
    if (auto xml = state.createXml())
        copyXmlToBinary (*xml, dest);
}

void MyProcessor::setStateInformation (const void* data, int size)
{
    if (auto xml = getXmlFromBinary (data, size))
        if (xml->hasTagName (apvts.state.getType()))
            apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessorEditor* MyProcessor::createEditor() { return new MyEditor (*this); }

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new MyProcessor();
}
