#pragma once

#include <juce_audio_utils/juce_audio_utils.h>
#include <juce_dsp/juce_dsp.h>

// An oscillator -> filter -> gain chain built from juce::dsp blocks
class Voice
{
public:
    enum { oscIndex, filterIndex, gainIndex };

    Voice()
    {
        chain.get<oscIndex>().initialise ([] (float x) { return std::sin (x); }, 128);  // lookup table
        chain.get<filterIndex>().setCutoffFrequencyHz (1000.0f);
        chain.get<filterIndex>().setResonance (0.7f);
        chain.get<gainIndex>().setGainLinear (0.1f);   // kept quiet so the demo is safe to run
    }

    void prepare (const juce::dsp::ProcessSpec& spec) { chain.prepare (spec); }
    void reset()                                       { chain.reset(); }

    template <typename Context>
    void process (const Context& context)              { chain.process (context); }

    void setFrequency (float hz, bool force = false)   { chain.get<oscIndex>().setFrequency (hz, force); }

private:
    juce::dsp::ProcessorChain<juce::dsp::Oscillator<float>,
                              juce::dsp::LadderFilter<float>,
                              juce::dsp::Gain<float>> chain;
};

class MainComponent final : public juce::AudioAppComponent
{
public:
    MainComponent();
    ~MainComponent() override;

    void prepareToPlay (int samplesPerBlockExpected, double sampleRate) override;
    void getNextAudioBlock (const juce::AudioSourceChannelInfo& info) override;
    void releaseResources() override;

private:
    Voice voice;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MainComponent)
};
