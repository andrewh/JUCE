#include "MainComponent.h"

MainComponent::MainComponent()
{
    setSize (400, 200);
    setAudioChannels (0, 2);   // no inputs, two outputs
}

MainComponent::~MainComponent()
{
    shutdownAudio();
}

void MainComponent::prepareToPlay (int samplesPerBlockExpected, double sampleRate)
{
    voice.prepare ({ sampleRate, (juce::uint32) samplesPerBlockExpected, 2 });
    voice.setFrequency (220.0f, true);
}

void MainComponent::getNextAudioBlock (const juce::AudioSourceChannelInfo& info)
{
    info.clearActiveBufferRegion();

    // Process only the region of the buffer JUCE asked us to fill
    juce::dsp::AudioBlock<float> block (*info.buffer);
    auto sub = block.getSubBlock ((size_t) info.startSample, (size_t) info.numSamples);
    voice.process (juce::dsp::ProcessContextReplacing<float> (sub));
}

void MainComponent::releaseResources()
{
    voice.reset();
}
