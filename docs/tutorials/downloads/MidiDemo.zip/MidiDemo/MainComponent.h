#pragma once

#include <juce_audio_utils/juce_audio_utils.h>

class MainComponent final : public juce::Component
{
public:
    MainComponent();

    void resized() override;

private:
    static juce::String describe (const juce::MidiMessage& m);

    juce::TextEditor log;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MainComponent)
};
