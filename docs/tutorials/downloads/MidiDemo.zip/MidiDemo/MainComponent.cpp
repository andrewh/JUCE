#include "MainComponent.h"

MainComponent::MainComponent()
{
    log.setMultiLine (true);
    log.setReadOnly (true);
    log.setFont (juce::FontOptions (juce::Font::getDefaultMonospacedFontName(), 14.0f, juce::Font::plain));
    addAndMakeVisible (log);

    const juce::MidiMessage messages[] =
    {
        juce::MidiMessage::noteOn (1, 60, (juce::uint8) 100),
        juce::MidiMessage::noteOff (1, 60),
        juce::MidiMessage::controllerEvent (10, 7, 90),
        juce::MidiMessage::programChange (1, 5),
        juce::MidiMessage::pitchWheel (1, 9000),
    };

    for (auto& m : messages)
        log.moveCaretToEnd(), log.insertTextAtCaret (describe (m) + "\n");

    setSize (400, 250);
}

void MainComponent::resized()
{
    log.setBounds (getLocalBounds().reduced (10));
}

juce::String MainComponent::describe (const juce::MidiMessage& m)
{
    if (m.isNoteOn())          return "Note on "  + juce::MidiMessage::getMidiNoteName (m.getNoteNumber(), true, true, 3);
    if (m.isNoteOff())         return "Note off " + juce::MidiMessage::getMidiNoteName (m.getNoteNumber(), true, true, 3);
    if (m.isProgramChange())   return "Program change " + juce::String (m.getProgramChangeNumber());
    if (m.isPitchWheel())      return "Pitch wheel " + juce::String (m.getPitchWheelValue());
    if (m.isChannelPressure()) return "Channel pressure " + juce::String (m.getChannelPressureValue());
    if (m.isAllNotesOff())     return "All notes off";

    if (m.isController())
    {
        juce::String name (juce::MidiMessage::getControllerName (m.getControllerNumber()));
        return "Controller " + (name.isEmpty() ? "[" + juce::String (m.getControllerNumber()) + "]" : name)
               + ": " + juce::String (m.getControllerValue());
    }

    return juce::String::toHexString (m.getRawData(), m.getRawDataSize());
}
