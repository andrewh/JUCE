#include "PluginEditor.h"

MyEditor::MyEditor (MyProcessor& p)
    : AudioProcessorEditor (&p), processorRef (p)
{
    setSize (300, 200);
}

void MyEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colours::black);
    g.setColour (juce::Colours::white);
    g.drawText ("My Plugin", getLocalBounds(), juce::Justification::centred);
}

void MyEditor::resized() {}
