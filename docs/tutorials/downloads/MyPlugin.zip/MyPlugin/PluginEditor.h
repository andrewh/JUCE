#pragma once

#include "PluginProcessor.h"

class MyEditor final : public juce::AudioProcessorEditor
{
public:
    explicit MyEditor (MyProcessor&);

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    [[maybe_unused]] MyProcessor& processorRef;   // not `processor`: the base class already has one

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MyEditor)
};
