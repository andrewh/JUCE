#include "PluginProcessor.h"
#include "PluginEditor.h"

MyProcessor::MyProcessor()
    : AudioProcessor (BusesProperties()
                        .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                        .withOutput ("Output", juce::AudioChannelSet::stereo(), true))
{
}

void MyProcessor::prepareToPlay (double, int) {}
void MyProcessor::releaseResources() {}

bool MyProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    // Only stereo in and stereo out
    return layouts.getMainOutputChannelSet() == juce::AudioChannelSet::stereo()
        && layouts.getMainInputChannelSet() == layouts.getMainOutputChannelSet();
}

void MyProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    // Clear any output channels that have no matching input, then pass audio through
    for (int i = getTotalNumInputChannels(); i < getTotalNumOutputChannels(); ++i)
        buffer.clear (i, 0, buffer.getNumSamples());
}

juce::AudioProcessorEditor* MyProcessor::createEditor() { return new MyEditor (*this); }

void MyProcessor::getStateInformation (juce::MemoryBlock&) {}
void MyProcessor::setStateInformation (const void*, int) {}

// This creates new instances of the plug-in. It is called by the format wrappers.
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new MyProcessor();
}
