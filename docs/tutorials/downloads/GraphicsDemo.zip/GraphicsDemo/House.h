#pragma once

#include <juce_gui_extra/juce_gui_extra.h>

// A wall: a checkerboard that fills whatever bounds it is given
class WallComponent final : public juce::Component
{
public:
    void paint (juce::Graphics& g) override
    {
        g.fillCheckerBoard (getLocalBounds().toFloat(), 30.0f, 10.0f,
                            juce::Colours::sandybrown, juce::Colours::saddlebrown);
    }
};

// A roof: a red triangle that fits its bounds
class RoofComponent final : public juce::Component
{
public:
    void paint (juce::Graphics& g) override
    {
        auto w = (float) getWidth();
        auto h = (float) getHeight();

        juce::Path roof;
        roof.addTriangle (0.0f, h, w, h, w * 0.5f, 0.0f);

        g.setColour (juce::Colours::red);
        g.fillPath (roof);
    }
};

// A house is a roof on top of a wall. It knows nothing about where it will be placed.
class HouseComponent final : public juce::Component
{
public:
    HouseComponent()
    {
        addAndMakeVisible (wall);   // add as child and show, in one call
        addAndMakeVisible (roof);
    }

    void resized() override
    {
        auto area = getLocalBounds();
        roof.setBounds (area.removeFromTop (area.getHeight() / 3));
        wall.setBounds (area);
    }

private:
    WallComponent wall;
    RoofComponent roof;
};
