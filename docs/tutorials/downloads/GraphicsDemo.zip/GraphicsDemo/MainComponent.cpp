#include "MainComponent.h"

MainComponent::MainComponent()
{
    addAndMakeVisible (house);
    addAndMakeVisible (cottage);
    setSize (600, 400);
}

void MainComponent::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colours::lightblue);

    g.setColour (juce::Colours::darkblue);
    g.setFont (juce::FontOptions (20.0f));
    g.drawText ("Hello, World!", 20, 40, 200, 40, juce::Justification::centred, true);

    g.setColour (juce::Colours::green);
    g.drawLine (10, 350, 590, 350, 5.0f);       // the ground
}

void MainComponent::resized()
{
    // Each house is placed by its bounds. Its parts position themselves.
    house.setBounds   (60, 150, 260, 200);
    cottage.setBounds (380, 240, 140, 110);
}
