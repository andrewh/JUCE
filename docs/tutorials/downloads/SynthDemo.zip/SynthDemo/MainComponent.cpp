#include "MainComponent.h"

MainComponent::MainComponent()
{
    setSize (400, 200);
    setAudioChannels (0, 2);   // no inputs, two outputs
}

MainComponent::~MainComponent()
{
    shutdownAudio();
}

void MainComponent::prepareToPlay (int, double) {}

void MainComponent::getNextAudioBlock (const juce::AudioSourceChannelInfo& info)
{
    // White noise at a safe level: -0.125 .. +0.125
    for (int ch = 0; ch < info.buffer->getNumChannels(); ++ch)
    {
        auto* out = info.buffer->getWritePointer (ch, info.startSample);

        for (int i = 0; i < info.numSamples; ++i)
            out[i] = random.nextFloat() * 0.25f - 0.125f;
    }
}

void MainComponent::releaseResources() {}
