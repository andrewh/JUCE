#include "MainComponent.h"

MainComponent::MainComponent()
{
    rollButton.onClick = [this]
    {
        auto roll = rng.nextInt (6) + 1;   // upper bound is exclusive: 0..5, plus one
        result.setText ("You rolled " + juce::String (roll), juce::dontSendNotification);
    };

    result.setJustificationType (juce::Justification::centred);
    result.setFont (juce::FontOptions (24.0f));

    addAndMakeVisible (rollButton);
    addAndMakeVisible (result);
    setSize (300, 160);
}

void MainComponent::resized()
{
    auto area = getLocalBounds().reduced (10);
    rollButton.setBounds (area.removeFromTop (40));
    result.setBounds (area);
}
