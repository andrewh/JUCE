#pragma once

#include <juce_gui_extra/juce_gui_extra.h>
#include <juce_osc/juce_osc.h>

class MainComponent final : public juce::Component
{
public:
    MainComponent();

    void resized() override;

private:
    juce::Random rng { 1234 };    // fixed seed: the same rolls every run. Use setSeedRandomly() for real dice.

    juce::TextButton rollButton { "Roll a die" };
    juce::Label result;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MainComponent)
};
