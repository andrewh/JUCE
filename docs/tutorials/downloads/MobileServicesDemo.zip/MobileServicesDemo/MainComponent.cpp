#include "MainComponent.h"

MainComponent::MainComponent()
{
    setSize (480, 640);   // ignored on phones and tablets, where the window is full screen
}

void MainComponent::paint (juce::Graphics& g)
{
    g.fillAll (getLookAndFeel().findColour (juce::ResizableWindow::backgroundColourId));
    g.setColour (juce::Colours::white);
    g.setFont (juce::FontOptions (18.0f));

    juce::String text;
    text << "Component: " << getWidth() << " x " << getHeight() << " logical pixels\n"
         << (getWidth() > getHeight() ? "Landscape" : "Portrait") << "\n";

    if (auto* display = juce::Desktop::getInstance().getDisplays().getPrimaryDisplay())
        text << "Display scale: " << display->scale << "\n"
             << "Display DPI: " << display->dpi << "\n"
             << "User area: " << display->userBounds.toString() << "\n";

    juce::String orientation;

    switch (juce::Desktop::getInstance().getCurrentOrientation())
    {
        case juce::Desktop::upright:              orientation = "Upright"; break;
        case juce::Desktop::upsideDown:           orientation = "Upside down"; break;
        case juce::Desktop::rotatedClockwise:     orientation = "Rotated clockwise"; break;
        case juce::Desktop::rotatedAntiClockwise: orientation = "Rotated anticlockwise"; break;
        case juce::Desktop::allOrientations:      break;
    }

    text << "Orientation: " << orientation;

    g.drawFittedText (text, getLocalBounds().reduced (16), juce::Justification::topLeft, 10);
}

void MainComponent::resized()
{
    repaint();   // the text above depends on the size
}
