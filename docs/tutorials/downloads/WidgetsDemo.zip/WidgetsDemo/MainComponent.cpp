#include "MainComponent.h"

MainComponent::MainComponent()
{
    title.setText ("Widgets", juce::dontSendNotification);
    title.setFont (juce::FontOptions (16.0f, juce::Font::bold));
    title.setJustificationType (juce::Justification::centred);
    addAndMakeVisible (title);

    caption.setText ("Text input:", juce::dontSendNotification);
    caption.attachToComponent (&input, true);   // sits to the left of `input`
    caption.setJustificationType (juce::Justification::right);

    input.setEditable (true);
    input.setText ("click to edit", juce::dontSendNotification);
    input.setColour (juce::Label::backgroundColourId, juce::Colours::darkblue);
    input.onTextChange = [this]
    {
        output.setText (input.getText().toUpperCase(), juce::dontSendNotification);
    };
    addAndMakeVisible (input);
    addAndMakeVisible (output);

    slider.setRange (0.0, 100.0);
    slider.setValue (50.0);
    slider.onValueChange = [this]
    {
        output.setText ("Slider: " + juce::String (slider.getValue()), juce::dontSendNotification);
    };
    addAndMakeVisible (slider);

    choice.addItem ("First", 1);
    choice.addItem ("Second", 2);
    choice.setSelectedId (1);
    choice.onChange = [this]
    {
        output.setText ("Chose: " + choice.getText(), juce::dontSendNotification);
    };
    addAndMakeVisible (choice);

    button.onClick = [this]
    {
        output.setText ("Clicked", juce::dontSendNotification);
    };
    addAndMakeVisible (button);

    setSize (400, 300);
}

void MainComponent::resized()
{
    auto area = getLocalBounds().reduced (10);
    title.setBounds   (area.removeFromTop (30));
    input.setBounds   (area.removeFromTop (30).withTrimmedLeft (100));
    output.setBounds  (area.removeFromTop (30).withTrimmedLeft (100));
    slider.setBounds  (area.removeFromTop (40));
    choice.setBounds  (area.removeFromTop (30));
    button.setBounds  (area.removeFromTop (40).reduced (60, 5));
}
